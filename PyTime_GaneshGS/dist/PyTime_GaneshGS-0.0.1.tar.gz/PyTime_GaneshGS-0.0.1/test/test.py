# Import classes from your brand new package
from PyTime_GaneshGS import PyTimeGaneshGS

#Create an object of class & call a method of it
time = PyTimeGaneshGS.PyTime()

#Allowed input types, string and integer
time = time.printTime("004")
print(time)
 

