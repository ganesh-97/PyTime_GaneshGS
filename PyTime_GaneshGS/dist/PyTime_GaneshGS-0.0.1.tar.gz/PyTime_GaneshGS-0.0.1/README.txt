# PyTime_GaneshGS

The Package which can convert an integer to required time format

For example:

200 can be converted to 02:00 AM 
1354 can be converted to 01:54 PM

Allowed input types:

String and Integer

